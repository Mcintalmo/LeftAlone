Thanks for downloading this Asset.
It helps me a lot and allows me to create more assets in the future.
If you publish a game using some of my asset, please send me a link :)
Enjoy!

License note:
This asset pack can be used in both free and commercial projects. 
You can modify it to suit your own needs. 
Credit is not needed but appreciated. 
You may not redistribute it or resell it.

~created by Yashe